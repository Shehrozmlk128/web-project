let card = document.querySelectorAll(".slider");
let challenge = document.querySelectorAll(".card");
let connect = document.getElementById("connect");

let count = 0;

card.forEach(function (cards, index) {
    cards.style.left = `${index * 100}%`
})

function myFun() {
    card.forEach(function (curVal) {
        curVal.style.transform = `translateX(-${100 * count}%)`
    })
}

setInterval(function () {
    count++;
    if (count == card.length) {
        count = 0
    }
    myFun()
}, 2000)


challenge.forEach(function(detail){
    detail.addEventListener("click",function(){
        document.querySelector(".container").innerHTML="";

        let div = document.createElement("div");
        div.classList.add("detailCard");
        div.innerHTML=`<h2>Challenges</h2>
        <p>12 Weeks</p>
        <img src=${detail.firstElementChild.src} alt="">
        <h3>About</h3>
        <p>Exercise is a subset of physical activity that is planned, structured, and repetitive and has as a final or an intermediate objective the improvement or maintenance of physical fitness</p>
        <button>Join</button>
        <a href="">Back</a>

      `  
      document.querySelector("body").appendChild(div)
        console.log(detail.firstElementChild);
    })
})


connect.addEventListener("click",function(){
    let name= document.getElementById("name");
    let email= document.getElementById("email");
    let pass= document.getElementById("pass");

    if(name.value == "" || email.value == "" || pass.value == ""){
        alert("Please Enter Details")
    }
    else{
        alert("Thanks For Connecting")
    }
})



function calculateBMI() {
    var heightInput = document.getElementById("height");
    var weightInput = document.getElementById("weight");
    var resultDiv = document.getElementById("result");
  
    var height = parseFloat(heightInput.value);
    var weight = parseFloat(weightInput.value);
  
    if (isNaN(height) || isNaN(weight)) {
      resultDiv.innerHTML = "Please enter valid height and weight.";
      return;
    }
  
    var bmi = weight / ((height / 100) ** 2);
    var category = "";
  
    if (bmi < 18.5) {
      category = "Underweight";
    } else if (bmi < 25) {
      category = "Normal weight";
    } else if (bmi < 30) {
      category = "Overweight";
    } else {
      category = "Obese";
    }
  
    resultDiv.innerHTML = "Your BMI is " + bmi.toFixed(2) + " (" + category + ")";
  }
  
  function calculateBMI() {
    var heightInput = document.getElementById("height");
    var weightInput = document.getElementById("weight");
    var resultDiv = document.getElementById("result");
  
    var height = parseFloat(heightInput.value);
    var weight = parseFloat(weightInput.value);
  
    if (isNaN(height) || isNaN(weight)) {
      resultDiv.innerHTML = "Please enter valid height and weight.";
      return;
    }
  
    var bmi = weight / ((height / 100) ** 2);
    var category = "";
  
    if (bmi < 18.5) {
      category = "Underweight";
    } else if (bmi < 25) {
      category = "Normal weight";
    } else if (bmi < 30) {
      category = "Overweight";
    } else {
      category = "Obese";
    }
  
    resultDiv.innerHTML = "Your BMI is " + bmi.toFixed(2) + " (" + category + ")";
  }
  